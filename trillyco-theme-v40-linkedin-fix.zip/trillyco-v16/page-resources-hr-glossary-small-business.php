<?php
/**
 * Template Name: HR Glossary for Small Businesses
 * Description: Comprehensive glossary of HR, recruiting, and talent acquisition terms for small businesses and startups in Seattle and the PNW.
 */
get_header();

// BreadcrumbList schema
if (function_exists('trillyco_output_breadcrumb_schema')) {
  trillyco_output_breadcrumb_schema([
    ['name' => 'Home', 'url' => '/'],
    ['name' => 'Resources', 'url' => '/resources/'],
    ['name' => 'HR Glossary for Small Businesses', 'url' => '/resources-hr-glossary-small-business/'],
  ]);
}
?>

<main id="main" class="aeo-page">

<section class="aeo-hero">
  <div class="wrap">
    <div class="aeo-hero-content">
      <span class="eyebrow"><span class="dot"></span>Trillium Hiring — Seattle HR Consulting</span>
      <h1>HR Glossary for Small Businesses</h1>
      <div class="aeo-answer-block">
        <p>A comprehensive reference of HR, recruiting, and talent acquisition terms — written for small business owners and startup founders in Seattle and the PNW who need to understand the language of people operations without an HR background.</p>
      </div>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">

    <div class="aeo-glossary-nav">
      <h2>Jump to Section</h2>
      <div class="glossary-letter-grid">
        <a href="#A">A</a><a href="#B">B</a><a href="#C">C</a><a href="#D">D</a><a href="#E">E</a><a href="#F">F</a><a href="#H">H</a><a href="#I">I</a><a href="#J">J</a><a href="#K">K</a><a href="#L">L</a><a href="#M">M</a><a href="#O">O</a><a href="#P">P</a><a href="#R">R</a><a href="#S">S</a><a href="#T">T</a><a href="#W">W</a>
      </div>
    </div>

    <!-- ═══ A ═══ -->
    <h2 id="A">A</h2>
    <dl class="aeo-glossary-list">
      <dt>Applicant Tracking System (ATS)</dt>
      <dd>Software that manages job postings, applications, and candidate pipelines in one place. For small businesses, an ATS prevents candidates from falling through the cracks and creates a repeatable hiring workflow. Common options include Greenhouse, Lever, Ashby, and Rippling.</dd>

      <dt>At-Will Employment</dt>
      <dd>A legal doctrine in most U.S. states (including Washington) that allows either the employer or employee to end the employment relationship at any time, for any lawful reason, with or without cause. Washington recognizes several exceptions including public policy, implied contract, and covenant of good faith.</dd>
    </dl>

    <!-- ═══ B ═══ -->
    <h2 id="B">B</h2>
    <dl class="aeo-glossary-list">
      <dt>Background Check</dt>
      <dd>A screening process that verifies a candidate's criminal history, employment history, education, and other records. Washington's Fair Chance Act (RCW 49.94) restricts when employers can ask about criminal history — generally not until after determining the candidate is otherwise qualified.</dd>

      <dt>Benefits Administration</dt>
      <dd>The process of managing employee benefits including health insurance, retirement plans (401k), paid time off, and other perks. For small businesses in Washington, benefits are a key differentiator in competitive hiring markets.</dd>
    </dl>

    <!-- ═══ C ═══ -->
    <h2 id="C">C</h2>
    <dl class="aeo-glossary-list">
      <dt>COBRA (Consolidated Omnibus Budget Reconciliation Act)</dt>
      <dd>Federal law that allows employees to continue health insurance coverage after leaving a job, typically for up to 18 months. Applies to employers with 20+ employees. Washington state has additional continuation coverage rules for smaller employers.</dd>

      <dt>Compensation Benchmarking</dt>
      <dd>The process of comparing your pay rates against market data for similar roles in your industry and geography. In Seattle, where tech salaries skew high, small professional services firms need localized benchmarking to remain competitive without overpaying.</dd>

      <dt>Contingent Worker</dt>
      <dd>A non-employee worker such as an independent contractor, freelancer, or agency temp. Misclassifying employees as independent contractors carries significant penalties under Washington state law and IRS rules.</dd>
    </dl>

    <!-- ═══ D ═══ -->
    <h2 id="D">D</h2>
    <dl class="aeo-glossary-list">
      <dt>DEI (Diversity, Equity, and Inclusion)</dt>
      <dd>Organizational practices and policies designed to create a workplace where people of all backgrounds have equal access to opportunities, feel valued, and can contribute fully. For small businesses, DEI efforts often focus on inclusive hiring practices and equitable pay.</dd>

      <dt>Direct Sourcing</dt>
      <dd>A recruiting strategy where employers proactively identify and engage potential candidates directly (through LinkedIn, referrals, events) rather than waiting for applications. Particularly effective for small businesses hiring for specialized roles in competitive Seattle markets.</dd>
    </dl>

    <!-- ═══ E ═══ -->
    <h2 id="E">E</h2>
    <dl class="aeo-glossary-list">
      <dt>Employee Handbook</dt>
      <dd>A document that outlines company policies, procedures, expectations, and employee rights. In Washington, having a clear handbook helps protect against wrongful termination claims and ensures compliance with state-specific requirements like paid sick leave and PFML.</dd>

      <dt>Employee Onboarding</dt>
      <dd>The process of integrating a new hire into an organization, typically spanning the first 30-90 days. Effective onboarding includes paperwork completion, role-specific training, cultural introduction, and setting 30/60/90-day goals. Research shows structured onboarding improves retention by 82%.</dd>

      <dt>Employer Brand</dt>
      <dd>The reputation and perception of a company as a place to work. For small businesses competing against larger employers, a strong employer brand — communicated through culture, values, and employee experience — is often the most cost-effective recruiting tool.</dd>

      <dt>EPOA (Equal Pay and Opportunities Act)</dt>
      <dd>Washington state law (RCW 49.48) that prohibits pay discrimination based on gender and restricts employers from asking about salary history. Employers must provide salary ranges in job postings for companies with 15+ employees.</dd>
    </dl>

    <!-- ═══ F ═══ -->
    <h2 id="F">F</h2>
    <dl class="aeo-glossary-list">
      <dt>FLSA (Fair Labor Standards Act)</dt>
      <dd>Federal law that establishes minimum wage, overtime pay, recordkeeping, and youth employment standards. Employees are classified as either exempt (salaried, no overtime) or non-exempt (hourly, overtime eligible). Misclassification is one of the most common and costly HR violations for small businesses.</dd>

      <dt>FMLA (Family and Medical Leave Act)</dt>
      <dd>Federal law providing eligible employees up to 12 weeks of unpaid, job-protected leave per year for specified family and medical reasons. Applies to employers with 50+ employees. Washington's PFML program provides additional paid leave benefits for smaller employers.</dd>

      <dt>Fractional HR</dt>
      <dd>A service model where a company gets access to senior HR leadership on a part-time or retainer basis, without the cost of a full-time HR director. For small businesses with 5-25 employees, fractional HR provides strategic guidance and hands-on support at a fraction of the cost.</dd>
    </dl>

    <!-- ═══ H ═══ -->
    <h2 id="H">H</h2>
    <dl class="aeo-glossary-list">
      <dt>Hiring Manager</dt>
      <dd>The person (often a team lead or founder) who makes the final decision on a hire. In small businesses, the hiring manager is frequently also the recruiter, interviewer, and onboarding lead — which is why structured processes matter.</dd>

      <dt>HR Compliance</dt>
      <dd>The practice of ensuring a company's policies, procedures, and practices comply with federal, state, and local employment laws. Washington passed 39 new employment laws in 2025 alone, making compliance an ongoing challenge for small businesses without dedicated HR staff.</dd>

      <dt>HRIS (Human Resources Information System)</dt>
      <dd>Software that centralizes employee data, payroll, benefits, and HR processes. For small businesses, platforms like Rippling, Gusto, and BambooHR combine HRIS functionality with payroll and benefits administration in a single system.</dd>
    </dl>

    <!-- ═══ I ═══ -->
    <h2 id="I">I</h2>
    <dl class="aeo-glossary-list">
      <dt>Independent Contractor</dt>
      <dd>A self-employed individual who provides services to a company but is not an employee. Washington uses an "ABC test" to determine worker classification. Misclassification can result in back taxes, penalties, and liability for unpaid benefits.</dd>

      <dt>Interview Scorecard</dt>
      <dd>A structured evaluation tool that rates candidates on predefined criteria, reducing bias and improving hiring consistency. Scorecards typically assess technical skills, cultural alignment, and role-specific competencies on a standardized scale.</dd>
    </dl>

    <!-- ═══ J ═══ -->
    <h2 id="J">J</h2>
    <dl class="aeo-glossary-list">
      <dt>Job Description</dt>
      <dd>A document that outlines the responsibilities, qualifications, and expectations for a role. Effective job descriptions focus on outcomes and impact rather than just tasks, and include salary ranges (required in Washington for companies with 15+ employees under the EPOA).</dd>
    </dl>

    <!-- ═══ K ═══ -->
    <h2 id="K">K</h2>
    <dl class="aeo-glossary-list">
      <dt>Key Performance Indicator (KPI)</dt>
      <dd>A measurable value that demonstrates how effectively a company achieves key business objectives. In HR, common KPIs include time-to-fill, cost-per-hire, employee turnover rate, and offer acceptance rate.</dd>
    </dl>

    <!-- ═══ L ═══ -->
    <h2 id="L">L</h2>
    <dl class="aeo-glossary-list">
      <dt>Labor Market</dt>
      <dd>The supply and demand for workers in a given geography or industry. As of early 2026, King County's unemployment rate is approximately 4.8%, indicating a competitive labor market where small businesses need strong hiring practices to attract talent.</dd>
    </dl>

    <!-- ═══ M ═══ -->
    <h2 id="M">M</h2>
    <dl class="aeo-glossary-list">
      <dt>Minimum Wage</dt>
      <dd>The lowest hourly rate an employer can legally pay. Washington state's minimum wage is $16.66/hour as of January 1, 2026. Seattle's minimum wage is higher at $20.24/hour for large employers. These rates are adjusted annually based on inflation.</dd>
    </dl>

    <!-- ═══ O ═══ -->
    <h2 id="O">O</h2>
    <dl class="aeo-glossary-list">
      <dt>Offer Letter</dt>
      <dd>A formal document extending a job offer to a candidate, including compensation, start date, and key terms. In Washington, offer letters should not include at-will disclaimers that conflict with state protections, and must comply with salary transparency requirements.</dd>

      <dt>Onboarding</dt>
      <dd>See <strong>Employee Onboarding</strong>. The structured process of bringing a new employee up to speed, typically spanning 30-90 days. Includes paperwork, training, cultural integration, and goal-setting.</dd>

      <dt>OSHA (Occupational Safety and Health Administration)</dt>
      <dd>Federal agency that sets and enforces workplace safety standards. Washington operates its own OSHA-approved state program through the Department of Labor & Industries (L&I), which covers most private-sector employers in the state.</dd>
    </dl>

    <!-- ═══ P ═══ -->
    <h2 id="P">P</h2>
    <dl class="aeo-glossary-list">
      <dt>PFML (Paid Family and Medical Leave)</dt>
      <dd>Washington state program that provides paid leave for medical reasons, family care, and bonding with a new child. Funded through employer and employee payroll contributions. Eligible employees can receive up to 12 weeks of medical leave, 12 weeks of family leave, or 16 weeks combined per year.</dd>

      <dt>PTO (Paid Time Off)</dt>
      <dd>Time away from work that employees can use for vacation, personal days, or illness. Washington requires employers to provide paid sick leave (1 hour per 40 hours worked). PTO policies beyond the legal minimum are at the employer's discretion and serve as a recruiting tool.</dd>
    </dl>

    <!-- ═══ R ═══ -->
    <h2 id="R">R</h2>
    <dl class="aeo-glossary-list">
      <dt>Recruiting Operations</dt>
      <dd>The systems, processes, and tools that make hiring efficient and repeatable. Includes job posting distribution, applicant tracking, interview scheduling, candidate communication, and offer management. For startups, building recruiting ops at 10-15 employees prevents hiring chaos at 25+.</dd>

      <dt>Retention Rate</dt>
      <dd>The percentage of employees who remain with a company over a given period. In professional services, median employee tenure is approximately 3.5 years. Low retention often signals issues with management, compensation, culture, or growth opportunities.</dd>
    </dl>

    <!-- ═══ S ═══ -->
    <h2 id="S">S</h2>
    <dl class="aeo-glossary-list">
      <dt>Severance</dt>
      <dd>Compensation and benefits provided to an employee upon termination. Not legally required in most cases, but increasingly common in Washington as a standard practice, particularly for layoffs. Severance agreements typically include a release of claims.</dd>

      <dt>Succession Planning</dt>
      <dd>The process of identifying and developing internal candidates to fill key roles when they become vacant. For small businesses, succession planning is often informal but critical — losing a key person without a plan can be existential.</dd>
    </dl>

    <!-- ═══ T ═══ -->
    <h2 id="T">T</h2>
    <dl class="aeo-glossary-list">
      <dt>Talent Acquisition</dt>
      <dd>The strategic process of identifying, attracting, and hiring skilled candidates. Goes beyond filling open roles to include workforce planning, employer branding, and building a pipeline of potential candidates before positions open.</dd>

      <dt>Time-to-Fill</dt>
      <dd>The number of days between posting a job and a candidate accepting an offer. The average time-to-fill across industries is approximately 36 days. For Trillium Hiring's clients, the average is 32 days. High time-to-fill often indicates process bottlenecks or misaligned job requirements.</dd>

      <dt>Turnover Rate</dt>
      <dd>The percentage of employees who leave a company during a given period, calculated as (number of separations / average headcount) × 100. A healthy turnover rate for small professional services firms is typically 10-15% annually. Rates above 20% warrant investigation.</dd>
    </dl>

    <!-- ═══ W ═══ -->
    <h2 id="W">W</h2>
    <dl class="aeo-glossary-list">
      <dt>Workers' Compensation</dt>
      <dd>Insurance that provides medical benefits and wage replacement to employees injured on the job. In Washington, workers' compensation is administered through the Department of Labor & Industries (L&I) and is mandatory for nearly all employers.</dd>
    </dl>

  </div>
</section>

<section class="aeo-cta-band">
  <div class="wrap">
    <div class="quote-band">
      <span class="eyebrow">Need help with HR?</span>
      <h2>Talk to Trillium Hiring</h2>
      <p>20-minute first call. We'll tell you in the first five minutes if we're the right fit — and if not, we'll point you to someone who is.</p>
      <div class="btn-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/thr-smb/" target="_blank" rel="noopener">Small Business Package</a>
        <a class="btn btn-startup" href="https://www.trilliumhiring.com/thr-hgs/" target="_blank" rel="noopener">Startup Package</a>
      </div>
    </div>
  </div>
</section>

<?php
// FAQPage schema
$glossary_faqs = [
  [
    'question' => 'What is an ATS and does my small business need one?',
    'answer' => 'An Applicant Tracking System (ATS) manages job postings, applications, and candidate pipelines. For small businesses with regular hiring needs, an ATS prevents candidates from falling through the cracks and creates a repeatable workflow. Common options include Greenhouse, Lever, Ashby, and Rippling.',
  ],
  [
    'question' => 'What is fractional HR?',
    'answer' => 'Fractional HR provides senior HR leadership on a part-time or retainer basis, without the cost of a full-time HR director. For small businesses with 5-25 employees, it provides strategic guidance and hands-on support at a fraction of the cost.',
  ],
  [
    'question' => 'What HR compliance issues matter most for small businesses in Washington?',
    'answer' => 'Key Washington HR compliance areas include the Equal Pay and Opportunities Act (salary transparency), Fair Chance Act (criminal history inquiries), PFML (paid family and medical leave), minimum wage requirements, and paid sick leave. Washington passed 39 new employment laws in 2025 alone.',
  ],
  [
    'question' => 'What is the average time-to-fill for small business hiring?',
    'answer' => 'The average time-to-fill across industries is approximately 36 days. For Trillium Hiring\'s clients, the average is 32 days. High time-to-fill often indicates process bottlenecks or misaligned job requirements.',
  ],
  [
    'question' => 'What is a healthy employee turnover rate?',
    'answer' => 'A healthy turnover rate for small professional services firms is typically 10-15% annually. Rates above 20% warrant investigation into management, compensation, culture, or growth opportunities.',
  ],
];
if (function_exists('trillyco_output_faq_schema')) {
  trillyco_output_faq_schema($glossary_faqs);
}
?>

</main>
<?php get_footer(); ?>
