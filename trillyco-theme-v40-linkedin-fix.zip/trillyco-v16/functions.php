<?php
/**
 * Trilly Co Theme Functions
 * Version: 20.0.0
 */

/**
 * AEO meta fields for landing pages
 * Registers meta keys for answer blocks, FAQs, and CTA settings.
 */
function trillyco_aeo_meta_boxes() {
  add_meta_box(
    'aeo_page_settings',
    'AEO Page Settings',
    'trillyco_aeo_meta_box_html',
    'page',
    'side',
    'default'
  );
}
add_action('add_meta_boxes', 'trillyco_aeo_meta_boxes');

function trillyco_aeo_meta_box_html($post) {
  $meta_title = get_post_meta($post->ID, '_aeo_meta_title', true);
  $meta_desc  = get_post_meta($post->ID, '_aeo_meta_description', true);
  $cta_text   = get_post_meta($post->ID, '_aeo_cta_text', true);
  $cta_url    = get_post_meta($post->ID, '_aeo_cta_url', true);
  wp_nonce_field('trillyco_aeo_meta', 'trillyco_aeo_nonce');
  ?>
  <p><label>Meta Title (60 chars)</label><br>
  <input type="text" name="_aeo_meta_title" value="<?php echo esc_attr($meta_title); ?>" maxlength="60" style="width:100%"></p>
  <p><label>Meta Description (155 chars)</label><br>
  <textarea name="_aeo_meta_description" maxlength="155" rows="3" style="width:100%"><?php echo esc_textarea($meta_desc); ?></textarea></p>
  <p><label>CTA Button Text</label><br>
  <input type="text" name="_aeo_cta_text" value="<?php echo esc_attr($cta_text); ?>" placeholder="Talk to Trillium Hiring" style="width:100%"></p>
  <p><label>CTA Button URL</label><br>
  <input type="url" name="_aeo_cta_url" value="<?php echo esc_url($cta_url); ?>" placeholder="https://www.trilliumhiring.com/" style="width:100%"></p>
  <?php
}

function trillyco_save_aeo_meta($post_id) {
  if (!isset($_POST['trillyco_aeo_nonce']) || !wp_verify_nonce($_POST['trillyco_aeo_nonce'], 'trillyco_aeo_meta')) return;
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if (!current_user_can('edit_post', $post_id)) return;

  update_post_meta($post_id, '_aeo_meta_title', sanitize_text_field($_POST['_aeo_meta_title'] ?? ''));
  update_post_meta($post_id, '_aeo_meta_description', sanitize_textarea_field($_POST['_aeo_meta_description'] ?? ''));
  update_post_meta($post_id, '_aeo_cta_text', sanitize_text_field($_POST['_aeo_cta_text'] ?? ''));
  update_post_meta($post_id, '_aeo_cta_url', esc_url_raw($_POST['_aeo_cta_url'] ?? ''));
}
add_action('save_post', 'trillyco_save_aeo_meta');
if (!defined('ABSPATH')) { exit; }

/**
 * Output JSON-LD schema markup in <head>
 * Adds Organization, LocalBusiness, FAQPage, and WebSite schema.
 */
function trillyco_schema_head() {
  $site_name = get_bloginfo('name');
  $site_url  = home_url('/');
  $logo_url  = get_template_directory_uri() . '/assets/images/logo-trillycorp.png';

  // ── Organization + LocalBusiness ──
  $org_schema = [
    '@context' => 'https://schema.org',
    '@type'    => ['Organization', 'LocalBusiness'],
    'name'     => 'Trilly Co.',
    'alternateName' => ['Trilly Corp', 'TrillyCo'],
    'description' => 'Operating studio behind Trillium Hiring — hands-on recruiting and HR operations for small businesses and startups in Seattle and the PNW.',
    'url'      => $site_url,
    'logo'     => $logo_url,
    'image'    => $logo_url,
    'foundingLocation' => [
      '@type' => 'Place',
      'name'  => 'Seattle, WA',
    ],
    'areaServed' => [
      '@type' => 'City',
      'name'  => 'Seattle',
      'containedInPlace' => [
        '@type' => 'State',
        'name'  => 'Washington',
      ],
    ],
    'address' => [
      '@type' => 'PostalAddress',
      'addressLocality' => 'Seattle',
      'addressRegion'   => 'WA',
      'addressCountry'  => 'US',
    ],
    'knowsAbout' => [
      'HR consulting',
      'Recruiting operations',
      'Talent acquisition',
      'Onboarding',
      'HR compliance',
      'Fractional HR',
      'ATS setup',
      'Hiring strategy',
    ],
    'sameAs' => [
      'https://www.linkedin.com/company/trilly-corp',
      'https://www.trilliumhiring.com',
    ],
    'contactPoint' => [
      '@type' => 'ContactPoint',
      'contactType' => 'sales',
      'email'       => 'info@trillycorp.com',
    ],
  ];

  echo '<script type="application/ld+json">' . wp_json_encode($org_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";

  // ── WebSite + SearchAction ──
  $website_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'WebSite',
    'name'     => $site_name,
    'url'      => $site_url,
    'potentialAction' => [
      '@type' => 'SearchAction',
      'target' => [
        '@type' => 'EntryPoint',
        'urlTemplate' => $site_url . '?s={search_term_string}',
      ],
      'query-input' => 'required name=search_term_string',
    ],
  ];

  echo '<script type="application/ld+json">' . wp_json_encode($website_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";

  // ── Speakable Specification (for voice AI: Alexa, Google, Siri) ──
  // Tells AI engines which content to read aloud
  $speakable_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'WebPage',
    'name'     => wp_get_document_title(),
    'url'      => (is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
    'speakable' => [
      '@type' => 'SpeakableSpecification',
      'cssSelector' => ['.aeo-answer-block p', '.aeo-hero-content p', 'h1', 'h2'],
      'xpath' => ['/html/head/title', '/html/head/meta[@name="description"]/@content'],
    ],
  ];
  echo '<script type="application/ld+json">' . wp_json_encode($speakable_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";
}
add_action('wp_head', 'trillyco_schema_head', 1);

/**
 * Output BreadcrumbList schema
 * Call with trillyco_output_breadcrumb_schema([['name' => 'Home', 'url' => '/'], ['name' => 'Resources', 'url' => '/resources/'], ...]);
 */
function trillyco_output_breadcrumb_schema($items) {
  if (empty($items)) return;
  $breadcrumb = [
    '@context' => 'https://schema.org',
    '@type'    => 'BreadcrumbList',
    'itemListElement' => [],
  ];
  foreach ($items as $i => $item) {
    $breadcrumb['itemListElement'][] = [
      '@type'    => 'ListItem',
      'position' => $i + 1,
      'name'     => wp_strip_all_tags($item['name']),
      'item'     => home_url($item['url']),
    ];
  }
  echo '<script type="application/ld+json">' . wp_json_encode($breadcrumb, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";
}

/**
 * Output ItemList schema (for resource hub pages)
 * Call with trillyco_output_item_list_schema([['name' => 'Title', 'url' => '/slug/', 'description' => '...'], ...]);
 */
function trillyco_output_item_list_schema($items) {
  if (empty($items)) return;
  $list = [
    '@context' => 'https://schema.org',
    '@type'    => 'ItemList',
    'itemListElement' => [],
  ];
  foreach ($items as $i => $item) {
    $list['itemListElement'][] = [
      '@type'    => 'ListItem',
      'position' => $i + 1,
      'name'     => wp_strip_all_tags($item['name']),
      'url'      => home_url($item['url']),
    ];
  }
  echo '<script type="application/ld+json">' . wp_json_encode($list, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";
}

/**
 * Add FAQPage schema to pages that have .faq-item elements.
 * Called from page templates via trillyco_faq_schema().
 */
function trillyco_output_faq_schema($faqs) {
  if (empty($faqs)) return;

  $faq_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'FAQPage',
    'mainEntity' => [],
  ];

  foreach ($faqs as $faq) {
    $faq_schema['mainEntity'][] = [
      '@type' => 'Question',
      'name'  => wp_strip_all_tags($faq['question']),
      'acceptedAnswer' => [
        '@type' => 'Answer',
        'text'  => wp_strip_all_tags($faq['answer']),
      ],
    ];
  }

  echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . "</script>\n";
}

function trillyco_setup() {
  add_theme_support('title-tag');
  add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
  add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'trillyco_setup');

function trillyco_enqueue() {
  wp_enqueue_style(
    'trillyco-style',
    get_stylesheet_uri(),
    [],
    '2.0.0'
  );
  wp_enqueue_script(
    'trillyco-script',
    get_template_directory_uri() . '/assets/js/main.js',
    [],
    '2.0.0',
    true
  );
  // Pass AJAX URL and nonce to JS (for form submission)
  wp_localize_script('trillyco-script', 'trillycoData', [
    'ajaxUrl' => admin_url('admin-ajax.php'),
    'nonce'   => wp_create_nonce('trillyco_contact'),
  ]);
}
add_action('wp_enqueue_scripts', 'trillyco_enqueue');

/**
 * Serve llms.txt from theme directory at domain root
 */
function trillyco_llms_txt() {
  if (strpos($_SERVER['REQUEST_URI'], '/llms.txt') !== false) {
    $llms_file = get_template_directory() . '/llms.txt';
    if (file_exists($llms_file)) {
      header('Content-Type: text/plain; charset=utf-8');
      header('X-Robots-Tag: noindex');
      readfile($llms_file);
      exit;
    }
  }
}
add_action('init', 'trillyco_llms_txt');

/**
 * Ensure WordPress core sitemaps are enabled
 * WP 5.5+ has built-in sitemaps at /wp-sitemap.xml
 * This adds our custom post types and pages if needed.
 */
function trillyco_sitemap_setup() {
  // WP sitemaps are enabled by default; this is a placeholder
  // for any custom sitemap modifications if needed.
}
add_action('init', 'trillyco_sitemap_setup');

/**
 * Contact form AJAX handler
 * On the WordPress side you can pipe this into HubSpot via
 * the HubSpot WP plugin's form submission hook, or simply
 * forward the POST to the HubSpot Forms API (v3).
 */
function trillyco_handle_contact() {
  check_ajax_referer('trillyco_contact', 'nonce');

  $name     = sanitize_text_field($_POST['name'] ?? '');
  $email    = sanitize_email($_POST['email'] ?? '');
  $audience = sanitize_text_field($_POST['audience'] ?? 'general');
  $message  = sanitize_textarea_field($_POST['message'] ?? '');

  if (empty($name) || !is_email($email)) {
    wp_send_json_error(['message' => 'Please fill in your name and a valid email.']);
  }

  // ── Forward to HubSpot Forms API ────────────────────────────
  // Replace PORTAL_ID and FORM_GUID with your HubSpot values.
  // Create one HubSpot form for small-business and one for startup,
  // then select the correct GUID based on the $audience value.
  $hs_portal = defined('TRILLYCO_HS_PORTAL') ? TRILLYCO_HS_PORTAL : '';
  $hs_forms  = [
    'small-business' => defined('TRILLYCO_HS_FORM_SMB')     ? TRILLYCO_HS_FORM_SMB     : '',
    'startup'        => defined('TRILLYCO_HS_FORM_STARTUP')  ? TRILLYCO_HS_FORM_STARTUP : '',
    'general'        => defined('TRILLYCO_HS_FORM_GENERAL')  ? TRILLYCO_HS_FORM_GENERAL : '',
  ];
  $form_guid = $hs_forms[$audience] ?? $hs_forms['general'];

  if ($hs_portal && $form_guid) {
    $hs_url = "https://api.hsforms.com/submissions/v3/integration/submit/{$hs_portal}/{$form_guid}";
    $payload = wp_json_encode([
      'fields' => [
        ['name' => 'firstname', 'value' => $name],
        ['name' => 'email',     'value' => $email],
        ['name' => 'message',   'value' => $message],
        ['name' => 'audience',  'value' => $audience], // custom HubSpot property
      ],
      'context' => [
        'pageUri'  => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '',
        'pageName' => 'Trilly Co - Home',
      ],
    ]);
    wp_remote_post($hs_url, [
      'headers'     => ['Content-Type' => 'application/json'],
      'body'        => $payload,
      'data_format' => 'body',
      'timeout'     => 15,
    ]);
  }

  // Fallback: email notification
  if (defined('TRILLYCO_NOTIFY_EMAIL') && TRILLYCO_NOTIFY_EMAIL) {
    wp_mail(
      TRILLYCO_NOTIFY_EMAIL,
      "[Trilly Co] New inquiry — {$audience}: {$name}",
      "Name: {$name}\nEmail: {$email}\nAudience: {$audience}\n\n{$message}"
    );
  }

  wp_send_json_success(['message' => "Thanks {$name} — we'll be in touch shortly."]);
}
add_action('wp_ajax_trillyco_contact',        'trillyco_handle_contact');
add_action('wp_ajax_nopriv_trillyco_contact', 'trillyco_handle_contact');
