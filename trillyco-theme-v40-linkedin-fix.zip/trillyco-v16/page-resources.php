<?php
/*
 * Template Name: Resources Hub
 */
get_header();
?>

<main id="main" class="aeo-hub">

<section class="aeo-hero">
  <div class="wrap">
    <div class="aeo-hero-content">
      <span class="eyebrow"><span class="dot"></span>Trillium Hiring — Seattle HR Consulting</span>
      <h1>HR &amp; Hiring Resources for Seattle Small Businesses</h1>
      <div class="aeo-answer-block">
        <p>Practical guides on HR compliance, recruiting operations, onboarding, and hiring costs — built for small businesses and startups in Seattle and King County. No fluff. Just what you need to make better people decisions.</p>
      </div>
      <div class="aeo-cta-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/thr-smb/" target="_blank" rel="noopener">Small Business Package</a>
        <a class="btn btn-startup" href="https://www.trilliumhiring.com/thr-hgs/" target="_blank" rel="noopener">Startup Package</a>
      </div>
    </div>
  </div>
</section>

<section class="aeo-hub-grid-section">
  <div class="wrap">
    <h2>All Resources</h2>
    <div class="aeo-hub-grid">

      <a class="aeo-hub-card" href="/resources-2026-pnw-hiring-trends/">
        <h3>2026 PNW Small Business Hiring Trends Report</h3>
        <p>Professional services firms (5–25 employees) across Washington, Oregon, and Idaho are navigating a cooling but still competitive labor market. Median tenure in professional services is 3.5 years, and King County unemployment hit 4.8% in early 2026. Discover what these hiring trends mean for small PNW firms and how they should adjust hiring strategy in 2026.</p>
        <span class="aeo-hub-card-link">Read the report →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-hr-consulting-for-law-firms-seattle/">
        <h3>HR Consulting for Seattle Law Firms: Services, Costs, and When to Hire Help</h3>
        <p>Seattle law firms must navigate 39 new Washington employment laws passed in 2025, reshaping requirements for hiring, pay transparency, leave, and HR compliance. This guide helps Seattle law firms understand what's changed, what HR consulting services cover, and when it makes sense to bring in outside support.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-hr-consulting-for-accounting-firms-seattle/">
        <h3>HR Consulting for Seattle Accounting Firms: A Guide to Compliance, Hiring, and HR Support</h3>
        <p>Accounting firms face unique HR challenges during tax season and year-round operations. Discover how to build HR systems that support your firm without slowing down client work.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-recruiting-operations-startup-seattle/">
        <h3>How Seattle Startups Build Recruiting Operations That Scale Their Business Beyond 10 Employees</h3>
        <p>Seattle startups typically need structured recruiting operations at 10-15 employees. Learn how to build a hiring system that scales without enterprise bloat.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-what-does-hr-consulting-cost-seattle/">
        <h3>How Much Does HR Consulting Costs in Seattle (2026 Rates, Retainers, and Pricing Models Explained)</h3>
        <p>Seattle HR consulting averages $142.38/hour, with fractional HR retainers typically ranging from $3,000–$6,000/month depending on scope and company size. This guide breaks down pricing models and what drives cost differences for small and mid-sized businesses.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-when-to-hire-hr-consultant-small-business-seattle/">
        <h3>When to Hire an HR Consultant for Your Small Business</h3>
        <p>Most Seattle small businesses benefit from HR consulting at 8-12 employees. Learn the key trigger events that signal it's time to bring in outside HR support before operational issues escalate.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-hr-compliance-small-business-washington-2026/">
        <h3>What Small Businesses in Washington Need to Know About HR Compliance in 2026</h3>
        <p>Washington passed 39 new employment laws in 2025, significantly impacting HR compliance requirements for small businesses. This guide explains key changes—including the Fair Chance Act, EPOA, and PFML—and what they mean for hiring, payroll, and workplace policies in 2026.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-onboarding-best-practices-small-teams-seattle/">
        <h3>Employee Onboarding Best Practices for Small Teams: How to Improve Retention in the First 90 Days</h3>
        <p>Effective onboarding is a structured 90-day process that determines early employee success and retention. Learn the 30–60–90 day framework, pre-boarding checklist, and key Washington-specific requirements for small teams.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-hr-consulting-small-business/">
        <h3>HR Consulting for Small Businesses in Seattle: When to Hire Help and What It Covers</h3>
        <p>Seattle small businesses (5–25 employees) typically need HR consulting when hiring becomes reactive or one person is managing too many HR responsibilities. Discover key trigger events and what a 30-day HR consulting engagement actually delivers for growing teams.</p>
        <span class="aeo-hub-card-link">Read guide →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-hr-glossary-small-business/">
        <h3>HR Glossary for Small Businesses</h3>
        <p>A comprehensive reference of 40+ HR, recruiting, and talent acquisition terms — written for small business owners who need to understand people operations without an HR background.</p>
        <span class="aeo-hub-card-link">Read glossary →</span>
      </a>

      <a class="aeo-hub-card" href="/resources-2026-seattle-hr-statistics/">
        <h3>2026 Seattle Small Business HR Statistics</h3>
        <p>Key HR, recruiting, and employment statistics for Seattle and Washington small businesses — sourced from BLS, SHRM, and King County EconPulse. Updated for 2026.</p>
        <span class="aeo-hub-card-link">View statistics →</span>
      </a>

    </div>
  </div>
</section>

<section class="aeo-cta-band">
  <div class="wrap">
    <div class="quote-band">
      <span class="eyebrow">Need hands-on help?</span>
      <h2>Talk to Trillium Hiring</h2>
      <p>20-minute first call. We'll tell you in the first five minutes if we're the right fit — and if not, we'll point you to someone who is.</p>
      <div class="btn-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/thr-smb/" target="_blank" rel="noopener">Small Business Package</a>
        <a class="btn btn-startup" href="https://www.trilliumhiring.com/thr-hgs/" target="_blank" rel="noopener">Startup Package</a>
      </div>
    </div>
  </div>
</section>

<?php
// BreadcrumbList schema
if (!function_exists('trillyco_output_breadcrumb_schema')) {
  // fallback if functions.php not loaded
} else {
  trillyco_output_breadcrumb_schema([
    ['name' => 'Home', 'url' => '/'],
    ['name' => 'Resources', 'url' => '/resources/'],
  ]);
}

// ItemList schema for all resource cards
if (function_exists('trillyco_output_item_list_schema')) {
  $resource_items = [
    ['name' => '2026 PNW Small Business Hiring Trends Report', 'url' => '/resources-2026-pnw-hiring-trends/'],
    ['name' => 'HR Consulting for Seattle Law Firms: Services, Costs, and When to Hire Help', 'url' => '/resources-hr-consulting-for-law-firms-seattle/'],
    ['name' => 'HR Consulting for Seattle Accounting Firms: A Guide to Compliance, Hiring, and HR Support', 'url' => '/resources-hr-consulting-for-accounting-firms-seattle/'],
    ['name' => 'How Seattle Startups Build Recruiting Operations That Scale Their Business Beyond 10 Employees', 'url' => '/resources-recruiting-operations-startup-seattle/'],
    ['name' => 'How Much Does HR Consulting Costs in Seattle (2026 Rates, Retainers, and Pricing Models Explained)', 'url' => '/resources-what-does-hr-consulting-cost-seattle/'],
    ['name' => 'When to Hire an HR Consultant for Your Small Business', 'url' => '/resources-when-to-hire-hr-consultant-small-business-seattle/'],
    ['name' => 'What Small Businesses in Washington Need to Know About HR Compliance in 2026', 'url' => '/resources-hr-compliance-small-business-washington-2026/'],
    ['name' => 'Employee Onboarding Best Practices for Small Teams: How to Improve Retention in the First 90 Days', 'url' => '/resources-onboarding-best-practices-small-teams-seattle/'],
    ['name' => 'HR Consulting for Small Businesses in Seattle: When to Hire Help and What It Covers', 'url' => '/resources-hr-consulting-small-business/'],
    ['name' => 'HR Glossary for Small Businesses', 'url' => '/resources-hr-glossary-small-business/'],
    ['name' => '2026 Seattle Small Business HR Statistics', 'url' => '/resources-2026-seattle-hr-statistics/'],
  ];
  trillyco_output_item_list_schema($resource_items);
}
?>
</main>
<?php get_footer(); ?>
