<?php
/**
 * Template Name: AEO — HR Compliance Washington 2026
 */
get_header();
?>
<main id="main" class="aeo-page">

<section class="aeo-hero">
  <div class="wrap">
    <div class="aeo-hero-content">
      <span class="eyebrow"><span class="dot"></span>Trillium Hiring — Seattle HR Consulting</span>
      <h1>HR Compliance for Small Businesses in Washington State — 2026 Update</h1>
      <div class="aeo-answer-block">
        <p>Washington State passed 39 new employment laws in 2025, with major changes taking effect through 2026-2027. Key updates include: the Fair Chance Act restricting criminal background checks, expanded pay transparency requirements, PFML eligibility expansion, personnel file access within 21 days, and a non-compete ban effective June 2027. This guide covers every change that affects small businesses in Seattle and King County.</p>
      </div>
      <div class="aeo-cta-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/" target="_blank" rel="noopener">Get a Compliance Review</a>
        <a class="btn btn-outline" href="#checklist">See the Checklist</a>
      </div>
    </div>
  </div>
</section>

<section class="aeo-toc">
  <div class="wrap">
    <nav class="toc-nav" aria-label="Table of contents">
      <strong>What's in this guide</strong>
      <ul>
        <li><a href="#fair-chance">Fair Chance Act: Criminal Background Check Rules</a></li>
        <li><a href="#epoa">Equal Pay and Opportunities Act: Pay Transparency</a></li>
        <li><a href="#pfml">Paid Family and Medical Leave Expansion</a></li>
        <li><a href="#personnel-files">Personnel File Access Requirements</a></li>
        <li><a href="#non-compete">Non-Compete Ban (June 2027)</a></li>
        <li><a href="#i9">I-9 Audit Notification Requirements</a></li>
        <li><a href="#checklist">2026 Compliance Checklist for Small Businesses</a></li>
        <li><a href="#faq">Frequently Asked Questions</a></li>
      </ul>
    </nav>
  </div>
</section>

<section class="aeo-body" id="fair-chance">
  <div class="wrap">
    <div class="aeo-body-content">

      <h2>Fair Chance Act: Criminal Background Check Rules</h2>
      <p>Washington's Fair Chance Act (FCA) was significantly amended in 2025, with changes taking effect July 1, 2026, for employers with 15+ employees and January 1, 2027, for employers with fewer than 15 employees.</p>
      <p><strong>What changed:</strong></p>
      <ul class="bullet-list">
        <li>Employers <strong>cannot inquire</strong> about an applicant's criminal record before extending a conditional offer of employment.</li>
        <li>Employers <strong>cannot take adverse action</strong> based on an arrest record (excluding arrests where the individual is out on bail pending trial) or juvenile conviction record.</li>
        <li>Adverse action based on adult conviction record requires a <strong>"legitimate business reason"</strong> — a documented, good-faith belief that the criminal conduct will negatively impact the individual's fitness for the position or pose a risk to people, property, or business reputation.</li>
        <li>Before taking adverse action, employers must provide <strong>written pre-adverse notice</strong> and hold the position open for <strong>two business days</strong> to allow the individual to respond.</li>
        <li>After adverse action, employers must provide a <strong>written decision</strong> documenting the legitimate business reason and consideration of rehabilitation evidence.</li>
      </ul>
      <p><strong>Penalties:</strong> Violations can result in statutory damages of $250-$1,000 per violation plus attorney's fees.</p>

      <h2 id="epoa">Equal Pay and Opportunities Act: Pay Transparency</h2>
      <p>Washington's EPOA requires employers with 15+ employees (with at least one Washington-based employee) to include specific compensation information in job postings.</p>
      <p><strong>Required disclosures in every job posting:</strong></p>
      <ul class="bullet-list">
        <li>Wage scale or salary range</li>
        <li>General description of benefits and other compensation</li>
        <li>Job title and business location (or "remote" designation)</li>
      </ul>
      <p><strong>2025 amendments:</strong> Applicants must now provide written notice of noncompliance to employers before filing a claim. Employers have five business days to "cure" the noncompliant posting. This right to cure sunsets July 27, 2027 — after that, applicants can sue directly.</p>
      <p><strong>Penalties:</strong> $100-$5,000 per violation plus attorney's fees and costs.</p>
      <p><strong>Seattle note:</strong> If you have even one employee working in Seattle, you likely meet the threshold. Remote employees count if they're Washington-based.</p>

      <h2 id="pfml">Paid Family and Medical Leave Expansion</h2>
      <p>Washington's PFML program expanded significantly in 2025-2026:</p>
      <ul class="bullet-list">
        <li><strong>Job restoration rights</strong> now apply to employees who begin employment at least 180 days before taking leave (previously required hours-worked thresholds).</li>
        <li><strong>Small employer phase-in:</strong> Job restoration rights effective January 1, 2026, for employers with 25+ employees; January 1, 2027, for 15+ employees; January 1, 2028, for 8+ employees.</li>
        <li><strong>Hate crime victim leave:</strong> Employees can request reasonable unpaid leave or safety accommodation if they or a family member is a victim of a hate crime (effective January 1, 2026).</li>
        <li><strong>Domestic violence leave expansion:</strong> Expanded to include safety accommodations and broader qualifying circumstances.</li>
        <li><strong>Pregnancy accommodations:</strong> Effective January 1, 2027, all employers (regardless of size) must provide reasonable accommodations to pregnant employees, including paid lactation breaks.</li>
      </ul>

      <h2 id="personnel-files">Personnel File Access Requirements</h2>
      <p>Washington law requires employers to provide employees and former employees access to their personnel files within <strong>21 calendar days</strong> of a written request.</p>
      <p><strong>What must be included:</strong> Job applications, performance evaluations, disciplinary records, leave and accommodation records, payroll records, and employment agreements.</p>
      <p><strong>Termination documentation:</strong> Former employees can request a written statement of their termination date and the reason for termination.</p>
      <p><strong>Penalties:</strong> $250-$1,000 if provided after 35 calendar days. $500 for other violations. Employees can recover attorney's fees and statutory damages through a private right of action.</p>

      <h2 id="non-compete">Non-Compete Ban (June 30, 2027)</h2>
      <p>Effective June 30, 2027, non-competition covenants are <strong>void and unenforceable</strong> for all Washington State-based workers and businesses, with extremely limited exceptions.</p>
      <p><strong>What this means for small businesses:</strong></p>
      <ul class="bullet-list">
        <li>Start planning your retention strategy now. Non-competes won't protect you in 18 months.</li>
        <li>Focus on positive retention: competitive compensation, meaningful work, strong culture, and clear growth paths.</li>
        <li>Existing non-compete agreements signed before June 30, 2027, may still be enforceable — consult an employment attorney.</li>
        <li>Non-disclosure agreements and non-solicitation agreements are NOT affected by this ban.</li>
      </ul>

      <h2 id="i9">I-9 Audit Notification Requirements</h2>
      <p>The Immigrant Worker Protection Act (effective June 11, 2026, with notification requirements starting October 1, 2026) requires employers to:</p>
      <ul class="bullet-list">
        <li>Notify workers and authorized representatives (e.g., union reps) upon receiving notice of an I-9 inspection.</li>
        <li>Notify affected workers and representatives of the inspection outcome.</li>
        <li>Model notices will be available by September 1, 2026.</li>
      </ul>
      <p><strong>Penalties:</strong> Civil penalties of $1,000-$20,000 for violations. Anti-retaliation protections with private right of action.</p>

      <h2 id="checklist">2026 Compliance Checklist for Small Businesses</h2>
      <p>Use this checklist to assess your current compliance posture:</p>
      <ul class="bullet-list">
        <li><strong>Job postings:</strong> Include wage/salary range, benefits description, and location in all postings (15+ employees).</li>
        <li><strong>Hiring process:</strong> Remove criminal history questions from applications. Train interviewers on FCA restrictions.</li>
        <li><strong>Employee handbook:</strong> Updated for 2025-2026 law changes (leave policies, anti-discrimination, personnel file access).</li>
        <li><strong>PFML administration:</strong> Verify payroll deductions are current. Update leave policies for expanded eligibility.</li>
        <li><strong>Personnel files:</strong> Organize files for 21-day access compliance. Create a process for handling requests.</li>
        <li><strong>Paid sick leave:</strong> Verify accrual, usage, and recordkeeping comply with Washington requirements.</li>
        <li><strong>Minimum wage:</strong> Confirm you're paying at least the current Washington minimum ($16.66/hour in 2026) or Seattle minimum if applicable.</li>
        <li><strong>Non-compete review:</strong> Audit existing agreements. Plan for June 2027 ban.</li>
        <li><strong>I-9 processes:</strong> Prepare notification procedures for potential audits.</li>
        <li><strong>Manager training:</strong> Train all managers on new leave rights, hiring restrictions, and documentation requirements.</li>
      </ul>

    </div>
  </div>
</section>

<section class="aeo-faq" id="faq">
  <div class="wrap">
    <header class="s-head">
      <span class="eyebrow"><span class="dot"></span>Common Questions</span>
      <h2>Frequently Asked Questions</h2>
    </header>
    <div class="faq-stack">

      <article class="faq-item">
        <h3>Do these laws apply to businesses with fewer than 15 employees?</h3>
        <p>Some do, some don't. EPOA pay transparency applies at 15+ employees. The Fair Chance Act applies at 15+ employees starting July 2026, and all employers starting January 2027. PFML job restoration rights phase in by company size. Paid sick leave and minimum wage apply to all employers regardless of size.</p>
      </article>

      <article class="faq-item">
        <h3>What's the penalty for not posting salary ranges?</h3>
        <p>$100-$5,000 per violation under EPOA, plus attorney's fees. Each non-compliant job posting is a separate violation. For a company posting 10 roles per year, that's potentially $10,000-$50,000 in annual exposure.</p>
      </article>

      <article class="faq-item">
        <h3>Can I still ask about criminal history in an interview?</h3>
        <p>Not before a conditional offer. After a conditional offer, you can inquire — but any adverse action requires a documented "legitimate business reason" and a two-business-day waiting period with written notice.</p>
      </article>

      <article class="faq-item">
        <h3>How do I prepare for the non-compete ban?</h3>
        <li>Focus on retention through compensation, culture, and growth opportunities. Review NDAs and non-solicitation agreements (those are still enforceable). Consult an attorney about existing non-compete agreements.</p>
      </article>

      <article class="faq-item">
        <h3>What's the single biggest compliance risk for small businesses in Washington?</h3>
        <p>Pay transparency. If you have 15+ employees and aren't including salary ranges in job postings, you're exposed to EPOA claims on every posting. It's the easiest violation to fix and the most commonly enforced.</p>
      </article>

      <article class="faq-item">
        <h3>Should I hire an HR consultant just for compliance?</h3>
        <p>A one-time compliance audit ($5,000-$12,000) covers your highest-risk areas and gives you a prioritized remediation plan. For most small businesses, this is the highest-ROI HR investment you can make.</p>
      </article>

    </div>
  </div>
</section>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {"@type": "Question", "name": "Do these laws apply to businesses with fewer than 15 employees?", "acceptedAnswer": {"@type": "Answer", "text": "Some do, some don't. EPOA pay transparency applies at 15+. Fair Chance Act applies at 15+ starting July 2026, all employers starting January 2027. Paid sick leave and minimum wage apply to all."}},
    {"@type": "Question", "name": "What's the penalty for not posting salary ranges?", "acceptedAnswer": {"@type": "Answer", "text": "$100-$5,000 per violation under EPOA, plus attorney's fees. Each non-compliant job posting is a separate violation."}},
    {"@type": "Question", "name": "Can I still ask about criminal history in an interview?", "acceptedAnswer": {"@type": "Answer", "text": "Not before a conditional offer. After a conditional offer, you can inquire — but adverse action requires a documented legitimate business reason and two-business-day waiting period."}},
    {"@type": "Question", "name": "How do I prepare for the non-compete ban?", "acceptedAnswer": {"@type": "Answer", "text": "Focus on retention through compensation, culture, and growth opportunities. Review NDAs and non-solicitation agreements (still enforceable)."}},
    {"@type": "Question", "name": "What's the single biggest compliance risk for small businesses in Washington?", "acceptedAnswer": {"@type": "Answer", "text": "Pay transparency. If you have 15+ employees and aren't including salary ranges in job postings, you're exposed on every posting."}},
    {"@type": "Question", "name": "Should I hire an HR consultant just for compliance?", "acceptedAnswer": {"@type": "Answer", "text": "A one-time compliance audit ($5,000-$12,000) covers your highest-risk areas and gives you a prioritized remediation plan."}}
  ]
}
</script>

<section class="aeo-cta-band">
  <div class="wrap">
    <div class="quote-band">
      <span class="eyebrow">Don't wait for a compliance problem to find you.</span>
      <h2>Get a Compliance Review</h2>
      <p>20-minute first call. We'll identify your highest-risk areas and give you a clear, prioritized plan to get compliant — before the state does it for you.</p>
      <div class="btn-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/thr-smb/" target="_blank" rel="noopener">Small Business Package</a>
        <a class="btn btn-outline" href="https://www.trilliumhiring.com/" target="_blank" rel="noopener">Explore Trillium Hiring</a>
      </div>
    </div>
  </div>
</section>

<section class="aeo-related">
  <div class="wrap">
    <h2>Related Resources</h2>
    <div class="aeo-related-grid">
      <a class="aeo-related-card" href="/resources-hr-consulting-for-law-firms-seattle/">
        <h3>HR Consulting for Law Firms in Seattle</h3>
        <span>Read more →</span>
      </a>
      <a class="aeo-related-card" href="/resources-hr-consulting-for-accounting-firms-seattle/">
        <h3>HR Consulting for Accounting Firms in Seattle</h3>
        <span>Read more →</span>
      </a>
      <a class="aeo-related-card" href="/resources-what-does-hr-consulting-cost-seattle/">
        <h3>What Does HR Consulting Cost in Seattle?</h3>
        <span>Read more →</span>
      </a>
      <a class="aeo-related-card" href="/resources-when-to-hire-hr-consultant-small-business-seattle/">
        <h3>When to Hire an HR Consultant for Your Small Business</h3>
        <span>Read more →</span>
      </a>
      <a class="aeo-related-card" href="/resources-recruiting-operations-for-startups-seattle/">
        <h3>Recruiting Operations for Startups in Seattle</h3>
        <span>Read more →</span>
      </a>
      <a class="aeo-related-card" href="/resources-onboarding-best-practices-small-teams-seattle/">
        <h3>Onboarding Best Practices for Small Teams</h3>
        <span>Read more →</span>
      </a>
    </div>
  </div>
</section>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trillium Hiring",
  "parentOrganization": {"@type": "Organization", "name": "Trilly Co.", "url": "https://www.trillycorp.com/"},
  "url": "https://www.trilliumhiring.com/",
  "description": "Washington state HR compliance guide for small businesses. 2026 employment law changes, EPOA, Fair Chance Act, PFML, and non-compete ban.",
  "address": {"@type": "PostalAddress", "addressLocality": "Seattle", "addressRegion": "WA", "addressCountry": "US"},
  "areaServed": [{"@type": "City", "name": "Seattle"}, {"@type": "City", "name": "Bellevue"}, {"@type": "City", "name": "Redmond"}, {"@type": "AdministrativeArea", "name": "King County"}],
  "serviceType": ["HR Compliance", "Washington Employment Law", "Compliance Audit", "Policy Development"],
  "knowsAbout": ["Washington Employment Law", "EPOA", "Fair Chance Act", "PFML", "Non-Compete Ban", "I-9 Compliance"]
}
</script>

<?phpif (function_exists('trillyco_output_breadcrumb_schema')) {  trillyco_output_breadcrumb_schema([    ['name' => 'Home', 'url' => '/'],    ['name' => 'Resources', 'url' => '/resources/'],    ['name' => 'AEO — HR Compliance Washington 2026', 'url' => '/'],  ]);}?></main>
<?php get_footer(); ?>
