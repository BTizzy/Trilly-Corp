<?php
/**
 * Template Name: AEO Landing Page
 * Description: Answer Engine Optimized landing page template for Trilly Corp resources.
 *              Features: answer-first format, FAQPage schema, LocalBusiness schema,
 *              internal linking, clean semantic HTML.
 */
get_header();

$meta_title = get_post_meta(get_the_ID(), '_aeo_meta_title', true);
$meta_desc  = get_post_meta(get_the_ID(), '_aeo_meta_description', true);
$faq_data   = get_post_meta(get_the_ID(), '_aeo_faq_data', true);
$cta_text   = get_post_meta(get_the_ID(), '_aeo_cta_text', true) ?: 'Talk to Trillium Hiring';
$cta_url    = get_post_meta(get_the_ID(), '_aeo_cta_url', true) ?: 'https://www.trilliumhiring.com/';
?>

<main id="main" class="aeo-page">

<!-- ═══════════════════════════════════════════════════
     AEO HERO — Answer-first format
     ═══════════════════════════════════════════════════ -->
<section class="aeo-hero">
  <div class="wrap">
    <div class="aeo-hero-content">
      <span class="eyebrow"><span class="dot"></span>Trillium Hiring — Seattle HR Consulting</span>
      <h1><?php the_title(); ?></h1>

      <!-- Direct answer block — optimized for AI extraction -->
      <div class="aeo-answer-block" itemprop="description">
        <?php
        // Output the first paragraph (answer block) from content
        $content = get_the_content();
        $paragraphs = explode('</p>', $content);
        if (!empty($paragraphs[0])) {
          echo $paragraphs[0] . '</p>';
        }
        ?>
      </div>

      <div class="aeo-cta-row">
        <a class="btn btn-smb" href="<?php echo esc_url($cta_url); ?>" target="_blank" rel="noopener"><?php echo esc_html($cta_text); ?></a>
        <a class="btn btn-outline" href="#faq">Read FAQs</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════
     TABLE OF CONTENTS
     ═══════════════════════════════════════════════════ -->
<?php
// Auto-generate TOC from H2 headings in content
$toc_items = [];
if (preg_match_all('/<h2[^>]*>(.*?)<\/h2>/', $content, $matches)) {
  foreach ($matches[1] as $i => $heading) {
    $id = 'section-' . ($i + 1);
    $toc_items[] = ['id' => $id, 'text' => wp_strip_all_tags($heading)];
  }
}
if (!empty($toc_items)) : ?>
<section class="aeo-toc">
  <div class="wrap">
    <nav class="toc-nav" aria-label="Table of contents">
      <strong>What's in this guide</strong>
      <ul>
        <?php foreach ($toc_items as $item) : ?>
          <li><a href="#<?php echo esc_attr($item['id']); ?>"><?php echo esc_html($item['text']); ?></a></li>
        <?php endforeach; ?>
      </ul>
    </nav>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════════════════════════════
     MAIN CONTENT
     ═══════════════════════════════════════════════════ -->
<section class="aeo-body">
  <div class="wrap">
    <div class="aeo-body-content">
      <?php
      // Output content (skip first paragraph since it's the answer block)
      $paragraphs = explode('</p>', $content);
      array_shift($paragraphs); // Remove answer block
      $remaining = implode('</p>', $paragraphs);

      // Add IDs to H2s for TOC linking
      $remaining = preg_replace_callback('/<h2([^>]*)>(.*?)<\/h2>/', function($m) {
        static $counter = 0;
        $counter++;
        return '<h2 id="section-' . $counter . '"' . $m[1] . '>' . $m[2] . '</h2>';
      }, $remaining);

      echo $remaining;
      ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════
     FAQ SECTION — with FAQPage schema
     ═══════════════════════════════════════════════════ -->
<?php
// Get FAQs from post meta or extract from content
$faqs = [];
if ($faq_data) {
  $faqs = json_decode($faq_data, true);
} else {
  // Try to extract FAQs from content (H3s following #faq heading)
  if (preg_match('/<h2[^>]*>.*?(?:FAQ|Frequently Asked Questions).*?<\/h2>(.*?)(?=<h2|$)/is', $content, $faq_section)) {
    if (preg_match_all('/<h3[^>]*>(.*?)<\/h3>\s*<p>(.*?)<\/p>/s', $faq_section[1], $matches, PREG_SET_ORDER)) {
      foreach ($matches as $match) {
        $faqs[] = [
          'question' => wp_strip_all_tags($match[1]),
          'answer'   => wp_strip_all_tags($match[2]),
        ];
      }
    }
  }
}

if (!empty($faqs)) : ?>
<section class="aeo-faq" id="faq">
  <div class="wrap">
    <header class="s-head">
      <span class="eyebrow"><span class="dot"></span>Common Questions</span>
      <h2>Frequently Asked Questions</h2>
    </header>
    <div class="faq-stack">
      <?php foreach ($faqs as $faq) : ?>
        <article class="faq-item">
          <h3><?php echo esc_html($faq['question']); ?></h3>
          <p><?php echo esc_html($faq['answer']); ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQPage JSON-LD Schema -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    <?php foreach ($faqs as $i => $faq) : ?>
    {
      "@type": "Question",
      "name": <?php echo wp_json_encode($faq['question']); ?>,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": <?php echo wp_json_encode($faq['answer']); ?>
      }
    }<?php echo ($i < count($faqs) - 1) ? ',' : ''; ?>
    <?php endforeach; ?>
  ]
}
</script>
<?php endif; ?>

<!-- ═══════════════════════════════════════════════════
     CTA BAND
     ═══════════════════════════════════════════════════ -->
<section class="aeo-cta-band">
  <div class="wrap">
    <div class="quote-band">
      <span class="eyebrow">Ready to fix the system?</span>
      <h2>Talk to Trillium Hiring</h2>
      <p>20-minute first call. We'll tell you in the first five minutes if we're the right fit — and if not, we'll point you to someone who is.</p>
      <div class="btn-row">
        <a class="btn btn-smb" href="https://www.trilliumhiring.com/thr-smb/" target="_blank" rel="noopener">Small Business Package</a>
        <a class="btn btn-startup" href="https://www.trilliumhiring.com/thr-hgs/" target="_blank" rel="noopener">Startup Package</a>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════
     RELATED RESOURCES — Internal linking
     ═══════════════════════════════════════════════════ -->
<section class="aeo-related">
  <div class="wrap">
    <h2>Related Resources</h2>
    <div class="aeo-related-grid">
      <?php
      // Get sibling AEO pages
      $related = new WP_Query([
        'post_type'      => 'page',
        'posts_per_page' => 6,
        'post__not_in'   => [get_the_ID()],
        'meta_key'       => '_wp_page_template',
        'meta_value'     => 'page-aeo-landing.php',
        'orderby'        => 'title',
        'order'          => 'ASC',
      ]);
      if ($related->have_posts()) :
        while ($related->have_posts()) : $related->the_post(); ?>
          <a class="aeo-related-card" href="<?php the_permalink(); ?>">
            <h3><?php the_title(); ?></h3>
            <span class="aeo-related-link">Read more →</span>
          </a>
        <?php endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════
     LOCAL BUSINESS + SERVICE SCHEMA
     ═══════════════════════════════════════════════════ -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Trillium Hiring",
  "parentOrganization": {
    "@type": "Organization",
    "name": "Trilly Co.",
    "url": "https://www.trillycorp.com/"
  },
  "url": "https://www.trilliumhiring.com/",
  "description": "Hands-on recruiting and HR operations for small businesses and startups in Seattle and the PNW.",
  "address": {
    "@type": "PostalAddress",
    "addressLocality": "Seattle",
    "addressRegion": "WA",
    "addressCountry": "US"
  },
  "areaServed": [
    {"@type": "City", "name": "Seattle"},
    {"@type": "City", "name": "Bellevue"},
    {"@type": "City", "name": "Redmond"},
    {"@type": "City", "name": "Kirkland"},
    {"@type": "City", "name": "Issaquah"},
    {"@type": "City", "name": "Kent"},
    {"@type": "City", "name": "Renton"},
    {"@type": "AdministrativeArea", "name": "King County"}
  ],
  "serviceType": [
    "HR Consulting",
    "Recruiting Operations",
    "Onboarding",
    "HR Compliance",
    "Fractional HR Leadership"
  ],
  "knowsAbout": [
    "Washington State Employment Law",
    "HR Compliance",
    "Recruiting",
    "Onboarding",
    "Employee Handbooks",
    "ATS Setup",
    "Hiring Process Design"
  ]
}
</script>

</main>
<?php get_footer(); ?>
